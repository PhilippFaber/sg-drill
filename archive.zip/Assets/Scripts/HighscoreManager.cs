using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HighScoreManager : MonoBehaviour
{
    public void SaveHighscore(string name)
    {
        Debug.Log("TODO Highscore (name = " + name + ")");
    }
}
