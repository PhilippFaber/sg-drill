# sg-drill
Serious Games Übung 2023

Dieses Projekt wurde mit **Unity 2022.2** erstellt, bitte nutzt diese Version.
